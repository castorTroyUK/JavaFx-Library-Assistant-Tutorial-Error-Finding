
package library.assistant.ui.main;



import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.stage.Stage;
import library.assistant.database.DatabaseHandler;


public class Main extends Application{
    
    @Override
    public void start(Stage stage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("/library/assistant/ui/login/login.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.setTitle("Library Assistant V1.0");
        stage.show();
        
        new Thread(() -> {
            DatabaseHandler.getInstance();
        }).start();
                
    }
    
    public static void main (String[] args){
        launch(args);
    }
    
}

