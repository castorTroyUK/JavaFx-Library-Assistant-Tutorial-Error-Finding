package library.assistant.alert;

import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Alert;

public class AlertMaker {
    
    public static void showSimpleAlert(String title, String content){
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        
        alert.showAndWait();
    }
    
    public static void showErrorMessage(String title, String content){
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(content);
        
        alert.showAndWait();
    }
    
    
    
}
